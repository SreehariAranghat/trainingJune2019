﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    class Program
    {
        static ATM atm = new ATM();
        static void Main(string[] args)
        {
            atm.ATMEvent += LogHandler;
            atm.ATMEvent += ATMMoneyMonitoringService;

            atm.WithDrawMoney(1000, 100);
            atm.DepositMoney(500, 500);

            atm.WithDrawMoney(12345,1000);
            atm.WithDrawMoney(34566, 350);

            atm.ATMEvent -= ATMMoneyMonitoringService;
        }

        private static void ATMMoneyMonitoringService(object sender, ATMEvent e)
        {
            if(e.TotalMoneyLeft < 500 && e.TotalMoneyLeft > 100)
            {
                Console.WriteLine($"TO MANAGER :Hi there money in the ATM is " +
                    $"only {e.TotalMoneyLeft}");
            }
            else if(e.TotalMoneyLeft < 100)
            {
                Console.WriteLine($"TO SENIOR MANAGER :Hi there money in the ATM is " +
                   $"only {e.TotalMoneyLeft}");
            }
        }

        private static void LogHandler(object sender, ATMEvent e)
        {
            string log = $"DATE : {DateTime.Now} [{e.TransactionType}]" +
                 $"| ISSUCCESS : {e.IsTransactionSuccessful} " +
                 $"| CUSTOMER ID : {e.CustomerId}" +
                 $"| AMOUNT : {e.Amount}" +
                 $"| MONEY LEFT : {e.TotalMoneyLeft}";

            Console.WriteLine(log);

            StreamWriter writer = new StreamWriter("ATMLOG.txt", true);
            writer.WriteLine(log);
            writer.Close();

        }
    }
}
