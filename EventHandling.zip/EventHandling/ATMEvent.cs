﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    public enum TransactionType
    {
        WithDraw,
        Deposit
    }
    public class ATMEvent : EventArgs
    {
        public int CustomerId { get; set; }
        public int Amount { get; set; }
        public TransactionType TransactionType { get; set; }
        public bool IsTransactionSuccessful { get; set; }
        public int TotalMoneyLeft { get; set; }
    }
}
