﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    public class ATM
    {
        private int TotalMoneyAvailable = 1000;
        public event EventHandler<ATMEvent> ATMEvent;
        public void DepositMoney(int customerId,int amount)
        {
            TotalMoneyAvailable += amount;
            ATMEvent(this,
                new EventHandling.ATMEvent
                {
                    Amount = amount,
                    CustomerId = customerId,
                    IsTransactionSuccessful = true,
                    TotalMoneyLeft = TotalMoneyAvailable,
                    TransactionType = TransactionType.Deposit

                });
            ;
        }

        public void WithDrawMoney(int customerId,int amount)
        {
            if(amount > 0 && amount <= TotalMoneyAvailable)
            {
                TotalMoneyAvailable -= amount;
                ATMEvent(this,
                   new EventHandling.ATMEvent
                   {
                       Amount = amount,
                       CustomerId = customerId,
                       IsTransactionSuccessful = true,
                       TotalMoneyLeft = TotalMoneyAvailable,
                       TransactionType = TransactionType.WithDraw

                   });
            }
            else
            {
                ATMEvent(this,
               new EventHandling.ATMEvent
               {
                   Amount = amount,
                   CustomerId = customerId,
                   IsTransactionSuccessful = false,
                   TotalMoneyLeft = TotalMoneyAvailable,
                   TransactionType = TransactionType.WithDraw

               }); ;
            }
        }
    }
}
