﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            int[] arr2 = new int[] { 1, 20, 30, 40, 50 };
            string[] strArry = new string[] { "Sree", "Bill", "Steve" };

            int [,] twoDArray = new int[3,3];

            twoDArray[0, 0] = 10;
            twoDArray[0, 1] = 30;

            twoDArray = new int[,]{
                                       { 1,10,30}
                                     ,{ 20,30,40}
                                     ,{ 30,50,80}
                                    };

            int[][] jaggedArry = new int[][] {
                  new int[]{ 10,10,10,20},
                  new int[]{ 30,40,20 },
                  new int[] { 10,20 }
                };

            int[][] ja2 = new int[3][];
            ja2[0] = new int[] { 10, 20 };
            ja2[1] = new int[] { 30, 40, 50 };

            for(int i=0;i<ja2.Length;i++)
            {
                for(int j=0;j<ja2[i].Length;j++)
                {
                    Console.Write(ja2[i][j] + ",");
                }

                Console.WriteLine();
            }

            arr[0] = 1;
            arr[1] = 100;
            arr[2] = 50;

            for(int i=0;i<10;i++)
            {
                Console.WriteLine(arr[i]);
            }

        }
    }
}
