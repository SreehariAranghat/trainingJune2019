﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OppsTraining2
{
    public partial class Account
    {
        partial void DisplayInformation();
        public int GetCurrentBalance()
        {
            return new Random().Next(10000, 9999);
        }
    }
}
