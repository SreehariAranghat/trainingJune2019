﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OppsTraining2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, object> data = new Dictionary<string, object>();
            data.Add("Name", "Sree");
            data.Add("Email", "sreehariis@gmail.com");
            data.Add("Mobile", "8970593379");

            var stuExpando = new ExpandoObject();
            var ec = (ICollection<KeyValuePair<string, object>>)stuExpando;

            foreach(var d in data)
            {
                ec.Add(d);
            }

            dynamic stu = stuExpando;

            //dynamic student = new { Name = "Sree", Email = "sreehariis@gmail.com" };
            DisplayStudentInfo(stu);
           
        }

        public static void DisplayStudentInfo(dynamic s)
        {
            s.RollNumber = 1000;
            Console.WriteLine(s.Name);
            Console.WriteLine(s.Email);
            Console.WriteLine(s.RollNumber);
            Console.WriteLine(s.Mobile);
        }
       
    }

    public static class ConsoleExtentions
    {
        public static void WriteLineInColor(this Program console
                                , string message
                                , ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
        }
    }
    public static class AcccountExtentions
    {
        public static void DisplayFullInfo(this Account account)
        {
            Console.WriteLine($"Account Name : {account.Name}");
            Console.WriteLine($"Balnace : {account.Balance}");
        }
    }
}
