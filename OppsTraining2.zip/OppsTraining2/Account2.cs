﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OppsTraining2
{
    public partial class Account
    {
        partial void DisplayInformation()
        {
            Console.WriteLine($"Your account balance is {Balance}");
        }

        public string Name { get; set; }
        public int Balance { get; private set; }
        public int Deposit(int amount)
        {
            Balance += amount;
            return Balance;
        }

        public int WithDraw(int amount)
        {
            if (amount >= Balance)
            {
                Balance -= amount;
                return amount;
            }
            else
                return 0;
        }

        public int WithDraw(int amount,int accountnumber, int chequeno = 0)
        {
            return new Random().Next(0, 10);
        }
    }
}
