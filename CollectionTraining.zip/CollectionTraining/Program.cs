﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;

namespace CollectionTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList list = new ArrayList();
            //list.Add(1);
            //list.Add(100);
            //list.Add(300);
            //list.Add("Sree");

            //list[0] = 20;

            //list.Insert(1, 65);
            //list.Remove(100);

            //list.Add(50);
            //int x = (int)list[10];

            //object o = 1;
            //int i = (int)o;

            //foreach(int i in list)
            //{
            //    Console.WriteLine(i);
            //}
            //Hashtable hash = new Hashtable();
            //hash.Add("560094", "Sanjay Nagar");
            //hash.Add(1, 15.6F);

            //Hashtable hashtable = new Hashtable();

            //hashtable.Add("Dan Brown", new string[] { "Book 1", "Book 2" });
            //hashtable.Add("Authur", new string[] { "Sherlockholmes", "Hound" });

            //string[] booksDanBrown = (string[])hashtable["Dan Brown"];

            //foreach(string book in booksDanBrown)
            //{
            //    Console.WriteLine(book);
            //}


            List<int> intArray = new List<int>();
            intArray.Add(10);
            intArray.Add(30);

            foreach (int i in intArray)
                Console.Write(i + ",");

            Dictionary<int, string> pinCodes = new Dictionary<int, string>();
            pinCodes.Add(560094, "New Bel Road");
            pinCodes.Add(560080, "NEw Address");



            foreach (KeyValuePair<int, string> pinCode in pinCodes)
            {
                Console.WriteLine($"{pinCode} : Address : {pinCodes[pinCode.Key]}");
            }
        }
    }
}
