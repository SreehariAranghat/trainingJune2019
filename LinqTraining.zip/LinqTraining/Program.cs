﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> customers = new List<Customer>();
            customers.Add(new Customer(10001, "Sree", "Karnataka"));
            customers.Add(new Customer(10002, "Tony", "Karnataka"));
            customers.Add(new Customer(10003, "Captain", "Kerala"));
            customers.Add(new Customer(10004, "Steve", "Kerala"));

            List<Account> accounts = new List<Account>();
            accounts.Add(new Account(1, 10001, "SAVINGS", 16000));
            accounts.Add(new Account(2, 10001, "CREDITCARD", 50000));
            accounts.Add(new Account(3, 10002, "SAVINGS", 18000));

            var accDetails = from customer in customers
                             join account  in accounts
                             on customer.CustomerId equals account.CustomerId
                             select new { Customer = customer, Acc = account };

            var accGroup = from customer in customers
                           join account in accounts
                           on customer.CustomerId equals account.CustomerId
                           group account by customer.CustomerId into CustomerGroup
                           select new { Customer = CustomerGroup.Key
                                        , Accounts = CustomerGroup.ToList() };

            Func<int, int, int> add = (x, y) => { return x + y; };
           PrintNumbers(add);

            //var kaCustomers = from customer in customers
            //                  where customer.State == "Karnataka" && customer.Name.IndexOf("S") == 0
            //                  select customer;
            var kaCustomers = customers.Where(d => d.State == "Karnataka" 
                                              && d.Name.IndexOf("S") > 0);
            accounts.Select(d => d.Amount).Sum();

            var disState = customers.Select(d => d.State).Distinct();

            foreach (var customer in accGroup)
            {
                Console.WriteLine($"Customer : {customer.Customer}");
                foreach(var account in customer.Accounts)
                {
                    Console.WriteLine($"\t{account.AccountId} - {account.Amount}");
                }
            }


            //foreach (var a in accDetails)
            //{
            //    Console.WriteLine($"Customer Name : {a.Customer.Name}" +
            //                     $" Account Id : {a.Acc.AccountId}" +
            //                     $" Account Type : {a.Acc.AccountType}" +
            //                     $" Amount : {a.Acc.Amount}");
            //}

            #region old
            //var kaCustomers = from customer in customers
            //                  where customer.State == "Karnataka" && customer.Name.IndexOf("S") == 0
            //                  select customer;

            //var kaCustomers = from customer in customers
            //                  where customer.Name.IndexOf("S") == 0
            //                  select new { CustomerName = customer.Name, State = customer.State };

            //var distntState = (from customer in customers
            //                   where customer.Name.IndexOf("S") == 0
            //                   select new { State = customer.State }).Distinct();

            //foreach(var state in distntState)
            //{
            //    Console.WriteLine(state.State);
            //}

            //foreach(var customer in kaCustomers)
            //{
            //    Console.WriteLine($"Name : {customer.CustomerName} : State : {customer.State}");
            //}
            //foreach(Customer c in kaCustomers)
            //{
            //    Console.WriteLine($"{c.CustomerId} : {c.Name}");
            //}

            #endregion
        }

        public static void PrintNumbers(Func<int,int,int> add)
        {
            Console.WriteLine(add(1, 2));
        }
    }
}
