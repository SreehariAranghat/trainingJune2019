﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTraining
{
    public class Account
    {
        public int AccountId { get; set; }
        public int CustomerId { get; set; }
        public string AccountType { get; set; }
        public int Amount { get; set; }

        public Account(int accountId
            , int customerId
            , string accountType
            , int amount)
        {
            AccountId = accountId;
            CustomerId = customerId;
            AccountType = accountType;
            Amount = amount;
        }
    }
}
