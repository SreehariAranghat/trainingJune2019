﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter The First Number : ");
            string firstNumber = Console.ReadLine();


           
            Console.Write("Enter The Second Number : ");
            string secondNumber = Console.ReadLine();

            if (!(string.IsNullOrEmpty(firstNumber) 
                || string.IsNullOrEmpty(secondNumber)))
            {
                int intFirstNumber; //  = int.Parse(firstNumber);
                int intSecondNumber;// = int.Parse(secondNumber);

                // int fn =  Convert.ToInt32(firstNumber);
                if(int.TryParse(firstNumber,out intFirstNumber) 
                    && int.TryParse(secondNumber,out intSecondNumber))
                {
                    int total = intFirstNumber + intSecondNumber;



                    Console.WriteLine("First Number:{0} + Second Number:{1} = {2}"
                                    , firstNumber, secondNumber, total);

                    Console.WriteLine($"First Number:{firstNumber} + Second Number:{secondNumber} = {total}");

                }
                else
                {
                    Console.WriteLine("One or more values is not a number");
                }


            }
            else
            {
                Console.Write("Blank values are not allowed");
            }
        }
    }
}
