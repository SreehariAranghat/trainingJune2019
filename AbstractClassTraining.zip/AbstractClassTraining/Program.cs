﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            JSE jSE = new JSE { EmployeeId = 10001, Name = "Sreehari" };
            Manager manager = new Manager { EmployeeId = 10002, Name = "Tony" };
            SeniorManager seniorManager = new SeniorManager { EmployeeId = 10003, Name = "CAptain" };
            #region oldcode
            //jSE.DisplayEmployeeDetails();
            //manager.DisplayEmployeeDetails();
            //seniorManager.DisplayEmployeeDetails();

            //jSE.CalculateSalary();
            //jSE.DisplaySalaryInformation();

            //manager.CalculateSalary();
            //manager.DisplaySalaryInformation(false);

            //seniorManager.CalculateSalary();
            //seniorManager.DisplaySalaryInformation();


            //Employee e = jSE + manager + seniorManager;
            //Console.WriteLine($"Total Salary Paid : {e.TotalSalary}");
            #endregion

            SortedSet<JSE> jseList = new SortedSet<JSE>();

            for(int i=0;i<3;i++)
            {
                Console.Write("NAME : ");
                string name = Console.ReadLine();
                Console.Write("EMMPLOYEE  ID : ");
                int employeeId = int.Parse(Console.ReadLine());

                JSE j = new JSE { EmployeeId = employeeId, Name = name };
                if (!jseList.Contains(j))
                    jseList.Add(j);
                else
                    Console.WriteLine("Employee Already Exist");
            }

            foreach (JSE jSE1 in jseList)
                jSE1.DisplayEmployeeDetails();
        }
    }
}
