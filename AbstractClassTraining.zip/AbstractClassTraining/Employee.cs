﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassTraining
{
    public enum EmployeeType
    {
         JSE = 1
        ,MANAGER 
        ,SENIORMANAGER
    }
    public abstract class Employee : IEquatable<Employee>
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public EmployeeType EmployeeType { get; protected set; }
        public int BaseSalary { get; protected set; }
        public int TravelAllowance { get; protected set; }

        public int TotalSalary { get; protected set; }

        public void DisplayEmployeeDetails()
        {
            Console.WriteLine($"Employee Id : {EmployeeId}" +
                              $"\nName : {Name}" +
                              $"\nDesignation : {EmployeeType}");
        }

        public abstract void CalculateSalary();
        public virtual void DisplaySalaryInformation()
        {
            DisplayEmployeeDetails();
            Console.WriteLine("--------------------SALARY DETAILS---------------");
            Console.WriteLine($"BASE SALARY : {BaseSalary}");
            Console.WriteLine($"TRAVEL ALLOWANCE : {TravelAllowance}");
        }

        public virtual void DisplaySalaryInformation(bool showEmployeeDeatils)
        {
            Console.WriteLine("--------------------SALARY DETAILS---------------");
            Console.WriteLine($"BASE SALARY : {BaseSalary}");
            Console.WriteLine($"TRAVEL ALLOWANCE : {TravelAllowance}");
        }

        public bool Equals(Employee other)
        {
            return this.EmployeeId == other.EmployeeId;
        }

        public static Employee operator +(Employee emp1, Employee emp2)
        {
            Employee employee = emp1;
            employee.TotalSalary = emp1.TotalSalary + emp2.TotalSalary;

            return employee;
                 
        }

    }

    public class JSE : Employee,IEquatable<JSE>,IComparable<JSE>
    {
        public JSE()
        {
            base.EmployeeType = EmployeeType.JSE;
            base.BaseSalary = 15000;
            base.TravelAllowance = 3000;
        }

        public override void CalculateSalary()
        {
            TotalSalary = BaseSalary + TravelAllowance;
        }

        public int Compare(JSE x, JSE y)
        {
            if (x.EmployeeId > y.EmployeeId)
                return 1;
            if (x.EmployeeId < y.EmployeeId)
                return -1;
            else
                return 0;


        }

        public int CompareTo(JSE y)
        {
            if (this.EmployeeId > y.EmployeeId)
                return 1;
            if (this.EmployeeId < y.EmployeeId)
                return -1;
            else
                return 0;
        }

        public bool Equals(JSE other)
        {
            return this.EmployeeId == other.EmployeeId;
        }
    }
    public class Manager : Employee {
        public int ProjectBonus { get; protected set; }
        public Manager() {
            BaseSalary = 30000; TravelAllowance = 5000; ProjectBonus = 10000;
            base.EmployeeType = EmployeeType.MANAGER; }
        public override void CalculateSalary()
        {
            TotalSalary = BaseSalary + TravelAllowance + ProjectBonus;
        }
        public override void DisplaySalaryInformation()
        {
            base.DisplaySalaryInformation(false);

            Console.WriteLine($"PROJECT BONUS : {ProjectBonus}");
        }


    }
     
    public class SeniorManager : Manager {
        public SeniorManager() {
            BaseSalary = 60000; TravelAllowance = 10000; ProjectBonus = 10000;
            base.EmployeeType = EmployeeType.SENIORMANAGER; } }
}
