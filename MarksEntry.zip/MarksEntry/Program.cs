﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarksEntry
{
    class Program
    {
        static Dictionary<int, List<int>> studentMarks = new Dictionary<int, List<int>>();

        static void Main(string[] args)
        {
            #region studentmarksentty
            //for (int i=0;i<3;i++)
            //{
            //    Console.Write("Enter Register Number : ");
            //    int registerNumber = int.Parse(Console.ReadLine());

            //    if(!studentMarks.ContainsKey(registerNumber))
            //    {
            //        List<int> marks = new List<int>();
            //        for(int m=0;m< 3;m++)
            //        {
            //            Console.Write("Marks[" + (m + 1) + "]");
            //            int currentMarks = int.Parse(Console.ReadLine());
            //            marks.Add(currentMarks);
            //        }

            //        studentMarks.Add(registerNumber, marks);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Marks For the Student are already available");
            //        i -= 1;
            //    }
            //}

            //string regno = "";

            //do
            //{
            //    Console.Write("Enter Reg No :");
            //    regno = Console.ReadLine();

            //    if (regno != "EXIT")
            //    {
            //        int r = int.Parse(regno);
            //        if (studentMarks.ContainsKey(r))
            //        {
            //            foreach(int marks in studentMarks[r])
            //            {
            //                Console.WriteLine($"{r} : Marks : {marks}");
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("Student does not exist");
            //        }
            //    }

            //} while (regno != "EXIT");

            #endregion

            #region sortedlist
            //SortedDictionary<int, string> studentList = new SortedDictionary<int, string>();
            //for(int i=0;i<4;i++)
            //{
            //    int regNo = int.Parse(Console.ReadLine());
            //    string name = Console.ReadLine();

            //    studentList.Add(regNo, name);
            //    Console.WriteLine("------------------------------");
            //}

            //for(int c =0;c<studentList.Count;c++)
            //{
            //    KeyValuePair<int, string> keyValuePair = studentList.ElementAt(c);
            //    Console.WriteLine($"REGNO : {keyValuePair.Key} : NAME : {keyValuePair.Value}");
            //}

            //string[] arry = new string[] { "Sree", "Bill", "Steve" };

            //for(int x=0;x< arry.Length;x++)
            //{
            //    string s = arry[x];
            //    Console.WriteLine(s);
            //}

            //foreach(string s in arry)
            //{
            //    Console.WriteLine(s);
            //}

            //foreach(KeyValuePair<int,string> keyValuePair in studentList.Reverse())
            //{
            //    Console.WriteLine($"REGNO : {keyValuePair.Key} : NAME : {keyValuePair.Value}");
            //}

            //List<int> i = new List<int>();
            #endregion

            Stack<string> superHeros = new Stack<string>();
            superHeros.Push("Tony Stark");
            superHeros.Push("Captain America");
            superHeros.Push("Hulk");

            int totalItems = superHeros.Count;
            for(int i=0;i<totalItems;i++)
            {
                string superHero = superHeros.Pop();
                Console.WriteLine(superHero);
            }

            Queue<string> superHeros2 = new Queue<string>();
            superHeros2.Enqueue("Tony Stark");
            superHeros2.Enqueue("Captain America");
            superHeros2.Enqueue("Hulk");

            int totalItems2 = superHeros2.Count;
            for (int i = 0; i < totalItems2; i++)
            {
                string superHero = superHeros2.Dequeue();
                Console.WriteLine(superHero);
            }

        }
    }
}
