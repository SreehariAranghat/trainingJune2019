﻿
using lnt.Utilities.MathLibray;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using l = lnt.Utilities.MathLibray;

namespace MathClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //Some single line comment
            /*
             * This comment can include multile lines
             * And another line
             */

            int addTotal = new l.Math().Add(3, 5);
            Console.WriteLine("Total : " + addTotal);

            Salutaion s = new Salutaion();
            s.SayHello();
        }
    }
}
