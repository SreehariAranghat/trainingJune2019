﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassByRefTest
{
    class Program
    {
        static void Main(string[] args)
        {
            int age=0,x=0;
            int y = 30;

            //PassByValue(x, y);
            //PassByRef(ref x,  y);
            //PassByOut(out x, y);

            //Console.WriteLine($"OUTSIDE METHOD : X:{x} / Y:{y}");

            ParamValues();
            ParamValues(1);
            ParamValues(1, "Sree", 10, 100);
            ParamValues("Sree", "Hello", "World");

        }

        public static void ParamValues(params object[] values)
        {
            foreach(object o in values)
            {
                Console.Write(o + " | ");
            }

            Console.WriteLine("");
        }

        public static void PassByValue(int x,int y)
        {
            x = new Random().Next(1000, 9999);
            y = new Random().Next(9999, 55555);

            Console.WriteLine($"INSIDE METHOD : X:{x} / Y:{y}");
        }

        public static void PassByRef(ref int age, int y,int x)
        {
            //x = new Random().Next(1000, 9999);
            y = new Random().Next(9999, 55555);
            age = int.Parse(Console.ReadLine());
            Console.WriteLine($"INSIDE METHOD : X:{x} / Y:{y}");
        }

        public static void PassByOut(out int age, int y,int x)
        {
            x = new Random().Next(1000, 9999);
            y = new Random().Next(9999, 55555);

            age = int.Parse(Console.ReadLine());

            Console.WriteLine($"INSIDE METHOD : X:{x} / Y:{y}");
        }
    }
}
