﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lnt.Utilities.MathLibray
{
    /// <summary>
    /// Library for creating math specific unilities
    /// </summary>
    public class Math
    {
        /// <summary>
        /// Add methods will add the two signed integers and 
        /// provide the total
        /// </summary>
        /// <param name="x">First Param - Allows Unsigned Values from -32000 to 320000</param>
        /// <param name="y">Second parameter to be given - Unsigned Integer</param>
        /// <returns>Return the sum of x and y</returns>
        public int Add(int x,int y)
        {
            return x + y;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public int Subtract(int x,int y)
        {
            return x - y;
        }
    }

    public class Salutaion
    {
        public void SayHello()
        {
            Console.WriteLine("Hello There");
        }
    }
}
