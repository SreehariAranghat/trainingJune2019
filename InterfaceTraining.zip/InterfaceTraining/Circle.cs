﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    public  interface IAreaCalulate
    {
        int Area();
    }


    public class Circle : IAreaCalulate
    {
        public int Radius { get; set; }

        public int Area()
        {
            return (int)(Math.PI * Math.Sqrt(Radius));
        }
    }

    public class Rectangle: IAreaCalulate
    {
        public int Length { get; set; }
        public int Width  { get; set; }

        public int Area()
        {
            return Length * Width;
        }
    }

    public class Cube : IAreaCalulate
    {
        public int Length { get; set; }
        public int Width  { get; set; }
        public int Height { get; set; }

        public int Area()
        {
            throw new NotImplementedException();
        }
    }
}
