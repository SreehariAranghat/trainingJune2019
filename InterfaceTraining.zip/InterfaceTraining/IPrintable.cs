﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    public interface IPrintable
    {
        void Print(string message);
    }

    public interface IScan
    {
        string Scan();
    }

    public interface IFaxService
    {
        void Fax(string message, int number);
    }

    public interface IMultiFunctionPrinter : IPrintable,IScan,IFaxService
    {

    }
}
