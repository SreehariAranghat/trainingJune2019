﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    public static class PrinterService
    {
        private static int TotalPrintCount { get; set; }
        public static float TotalMoney {  get { return TotalPrintCount * .040F; } }


        public static void Print(string message,IPrintable printer)
        {
            //Print the data using printer
            printer.Print(message);
            TotalPrintCount += 1;
        }
    }

    public static class ScanService
    {
        private static int TotalPrintCount { get; set; }
        public static float TotalMoney { get { return TotalPrintCount * 1.0F; } }


        public static void Scan(IScan scanner)
        {
            //Print the data using printer
            string scanMEssage = scanner.Scan();
            Console.WriteLine(scanMEssage);
            TotalPrintCount += 1;
        }
    }
}
