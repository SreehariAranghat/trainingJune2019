﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    public static class PrinterFactory
    {
       

        public static IPrintable Creat()
        {
            string printerNAme = ConfigurationManager.AppSettings["printer"];
            IPrintable printable = null;

            switch(printerNAme)
            {
                case "HP": printable = new HPInkJet1000();break;
                default: printable = new CanonColorLaser100();break;
            }

            return printable;
            
        }
    }
}
