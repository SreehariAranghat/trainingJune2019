﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    public class HPInkJet1000 : IPrintable
    {
        public void Print(string message)
        {
            Console.WriteLine("#HPDESKJET :" + message);
        }
    }

    public class CanonColorLaser100 : IPrintable,IScan
    {
        public void Print(string message)
        {
            Console.WriteLine("PRINTING IN COLOR USING CANON :" + message);
        }

        public string Scan()
        {
            return "SCAN dATA :" + Guid.NewGuid().ToString();
        }
    }

    public class CanonColorLaser1000 : IPrintable, IScan,IFaxService
    {
        public void Fax(string message, int number)
        {
            Console.WriteLine("SENDING MESSAGE TO " + number + " MESSAGE : " + message);
        }

        public void Print(string message)
        {
            Console.WriteLine("PRINTING IN COLOR USING CANON :" + message);
        }

        public string Scan()
        {
            return "SCAN dATA :" + Guid.NewGuid().ToString();
        }
    }
}
