﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTraining
{
    class Program
    {
        static void Main(string[] args)
        {

            IPrintable printer = PrinterFactory.Creat();

            PrinterService.Print("Some data", printer);
            PrinterService.Print("IMAGE", printer);
            PrinterService.Print("REcipt", printer);

            Console.WriteLine($"Total Cost {PrinterService.TotalMoney}");

           

        }
    }
}
