﻿#define V_1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace PreProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            #region printingcode
            Console.WriteLine("Some Line of code");
            Console.WriteLine("Another aline of code");
            #endregion

            #if (V_1)
                    Console.WriteLine("This part if only for version 1");
            #endif

            showMessage();
        }

        static void showMessage()
        {
            #warning showMessge is depreciated use showMessage(message,font) inted
            #if DEBUG
            #warning Color will be set only in debug mode
            Console.ForegroundColor = ConsoleColor.Red;
            #endif

            Console.WriteLine("Hello There");
        }

        static void showMessage(string message,string font)
        {

            Console.WriteLine(message);
        }
    }
}
