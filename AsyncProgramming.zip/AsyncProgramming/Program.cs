﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncProgramming
{
    class Program
    {
        static  void Main(string[] args)
        {
            //StartCounter1()
            //    .ContinueWith(nexttask => {
            //        Console.WriteLine("Task 1 is completed starting with task 2");
            //    })
            //    ; 

            //Counter2();
            CancellationTokenSource source = new CancellationTokenSource();
            CancellationToken token = source.Token;
            

            DownloadImages(token);
            DownloadVideos(token);

            Thread.Sleep(3000);
            source.Cancel();

            Console.ReadLine();
        }

        public static async Task DownloadImages(CancellationToken cancellationToken)
        {
            await Task.Run(() => {
                for(int i=0;i< 100;i++)
                {
                    if(!cancellationToken.IsCancellationRequested)
                    {
                        Console.WriteLine($"Downloading File {i}.jpg");
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        Console.WriteLine("CANCELLING FILE DOWNLOAD");
                        break;
                    }
                }

            });
        }

        public static async Task DownloadVideos(CancellationToken cancellationToken)
        {
            await Task.Run(() => {
                for (int i = 0; i < 100; i++)
                {
                    if (!cancellationToken.IsCancellationRequested)
                    {
                        Console.WriteLine($"Downloading Video {i}.mpg");
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        Console.WriteLine("CANCELLING video DOWNLOAD");
                        break;
                    }
                }

            });
        }

        public static async Task StartCounter1()
        {
            await Task.Run(async () => { int counter = await GetUpperLimit();
                Counter1(counter); });
        }

        public static async Task Counter1(int counter)
        {
            await Task.Run(() => {
                
                for (int i = 0; i < counter; i++)
                {
                    Console.WriteLine($"COUNTER 1: {i}");
                }
            });
            
        }

        public static async Task<int> GetUpperLimit()
        {
            int counter = 0;
            Console.Write("ENTER UPPER LIMIT");
            counter =  int.Parse(Console.ReadLine());
            return counter;
        }

        public static void Counter2()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine($"COUNTER 2: {i}");
            }
        }
    }
}
