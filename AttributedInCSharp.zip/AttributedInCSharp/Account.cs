﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AttributedInCSharp
{
   
    [BankDetails("XYZ BANK",IFSCCODE = "XYZ00001")]
    public class Account
    {
        public int AccountBalance { get; set; }

        [PrincipalPermission(SecurityAction.Demand,Role = "Admin")]
        public void DepositMoney(int amount)
        {
            AccountBalance += amount;
            Console.WriteLine($"Deposited {amount} by {Thread.CurrentPrincipal.Identity.Name}");
        }
    }
}
