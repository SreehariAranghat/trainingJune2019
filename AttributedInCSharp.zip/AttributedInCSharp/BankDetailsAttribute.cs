﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributedInCSharp
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface)]
    public class BankDetailsAttribute : Attribute
    {
        public string BankName { get; private set; }
        public string IFSCCODE { get; set; }
        public BankDetailsAttribute(string bankName)
        {
            this.BankName = bankName;
        }
    }
}
