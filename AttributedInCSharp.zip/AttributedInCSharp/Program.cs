﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AttributedInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericIdentity identity = new GenericIdentity("Sree");
            GenericPrincipal principal = new GenericPrincipal(identity, new string[] { "Admin" });

            Thread.CurrentPrincipal = principal;

            Account account = new Account();
            account.DepositMoney(1000);

            var type = account.GetType();

            foreach(var a in type.GetCustomAttributes(true))
            {
                BankDetailsAttribute detailsAttribute = (BankDetailsAttribute)a;

                Console.WriteLine($"BANK NAME : {detailsAttribute.BankName}");
                Console.WriteLine($"IFSC CODE : {detailsAttribute.IFSCCODE}");
            }
        }
    }
}
