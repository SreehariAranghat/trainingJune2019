﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesTraining
{
    public class EmailService
    {
        public static void sentEmail(string message)
        {
            Console.WriteLine("SENDING EMAIL :" + message);
        }
    }
}
