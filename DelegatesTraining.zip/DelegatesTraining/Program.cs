﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DelegatesTraining
{
    public class Program
    {
        delegate void MessageDelegate(string message);
        delegate void FileDownloadCompleteCallBack(string fileName,string fileContent);

        delegate int GetDayAndYear();

        static void Main(string[] args)
        {
            MessageDelegate messageDelegate = new MessageDelegate(showWelcomeMessageInColor);
            messageDelegate                 += sentSMSMessage;
            messageDelegate                 += EmailService.sentEmail;

            FileDownloadCompleteCallBack completeCallBack 
                = new FileDownloadCompleteCallBack(FileService.SaveFileDetails);
            

            MessageCollectAndDisplay(messageDelegate);

            GetDayAndYear getDayAndYear = new GetDayAndYear(getCurrentDate);
            getDayAndYear += getCurrentYear;

            foreach (var d in getDayAndYear.GetInvocationList())
            {
                int date = (int)d.DynamicInvoke();
                Console.WriteLine(date);
            }


           
        }

        static int getCurrentDate()
        {
            return DateTime.Now.Day;
        }

        static int getCurrentYear()
        {
            return DateTime.Now.Year;
        }

        static void sentSMSMessage(string message)
        {
            Console.WriteLine($"SENDING SMS : {message}");
        }

        static void showWelcomeMessageInColor(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
        }

        static void MessageCollectAndDisplay(MessageDelegate messageDelegate)
        {
            string mesage = Console.ReadLine();
            messageDelegate(mesage);

        }

        static void DownloadFile(FileDownloadCompleteCallBack callBack)
        {
            Thread.Sleep(1000);
            callBack("data.txt", "Contents in the file");
        }
    }
}
