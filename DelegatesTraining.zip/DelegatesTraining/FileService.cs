﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesTraining
{
    public class FileService
    {
        public static void SaveFileDetails(string fileName,string fileConent)
        {
            Console.WriteLine($"File Name : {fileName}, fileContent{fileConent}");
        }
    }
}
