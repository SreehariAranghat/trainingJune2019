﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerTraining
{
    public class TimeZones
    {
        Dictionary<string, string> timeZones 
            = new Dictionary<string, string>();

        public TimeZones()
        {
            timeZones.Add("0", "GMT");
            timeZones.Add("+5:30", "IST");
            timeZones.Add("-4:00", "EST");
        }

        public string GetTimeZone(string key)
        {
            return timeZones[key];
        }

        public string this[string timezone]
        {
                get
                {
                    return this.timeZones[timezone];
                }
        }

        public string this[int index]
        {
            get
            {
                return this
                            .timeZones
                            .ElementAt(index)
                            .Value;
            }
        }



    }
}
