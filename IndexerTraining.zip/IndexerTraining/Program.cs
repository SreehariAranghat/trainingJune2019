﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> str = new List<string>();
            var r =  str[0];

            TimeZones zones = new TimeZones();

            string timeZone  = zones["+5:30"];
            string firstZone = zones[0];
        }
    }
}
