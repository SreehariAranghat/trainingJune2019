﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingTraining
{
    public class InsufficientBalanceException : ApplicationException
    {
        public int Balance { get; private set; }
        public int RequestAmount { get; private set; }
        public InsufficientBalanceException() : base()
        {

        }

        public InsufficientBalanceException(string message) : base(message) { }
        public InsufficientBalanceException(string message,Exception innerException) 
                : base(message,innerException)
        { 
        }
            
        public InsufficientBalanceException(string message,int balance,int requestAmount) 
            : base(message)
        {
            this.Balance = balance;
            this.RequestAmount = requestAmount;
        }

        public override string ToString()
        {
            string errorMessage = $"Dear Account Holder, Your balance is {Balance}" +
                $".And you have requested to withdraw {RequestAmount}. Thank you";
            return errorMessage;
        }
    }
}
