﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingTraining
{
    public class Account 
    {
        public int Balance { get; set; } 

        public int WithDrawAmount(int amount)
        {
            if (amount <= Balance)
                return amount;
            else
            {
                throw new InsufficientBalanceException("Balance is Low", Balance, amount);
            }
        }
        public int Deposit(string value)
        {
            //try
            //{
                int amount = int.Parse(value);

                if (amount <= 0)
                    throw new ArgumentException("Deposit amount must be greater than 0");

                Balance += amount;
            //}
            //catch(Exception excp)
            //{
            //    throw new Exception("Some random Excption");
            //    throw excp;
            //    //throw formatException

            //}
            
            return Balance;
        }
    }
}
