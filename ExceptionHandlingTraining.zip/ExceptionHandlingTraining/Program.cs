﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingTraining
{
    class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Account account = new Account();
                string amount = Console.ReadLine();
                account.Deposit(amount);
                account.WithDrawAmount(300);
            }
            catch(InsufficientBalanceException insuffifienceBalance)
            {
                Console.WriteLine(insuffifienceBalance.ToString());
            }
            catch (FormatException excp)
            {
                Console.WriteLine("Looks like the data" +
                    " you entered is not a number");
                LogErrorMessage(excp);
            }
            catch (OverflowException overFlowExcp)
            {
                Console.WriteLine("Its a large number we cant handle");
                LogErrorMessage(overFlowExcp);
            }
            catch (DivideByZeroException divideByZeroException)
            {
                Console.WriteLine("Sorry the age must be greater than zero");
                LogErrorMessage(divideByZeroException);
            }
            catch (Exception exp)
            {
                throw;
                Console.WriteLine(exp.Message);
                Console.WriteLine("Oops something really bad happened");
            }
            catch
            {

            }
            finally
            {
                Console.WriteLine("This code will be always executed");
            }
        }

        static void LogErrorMessage(Exception exp)
        {
            Console.WriteLine(exp.Source);
            Console.WriteLine(exp.StackTrace);
            Console.WriteLine(exp.Message);

            StreamWriter writer = new StreamWriter("Log.txt", true);
            writer.WriteLine($"{DateTime.Now} : {exp.Message} " +
                             $"/ Stack : {exp.StackTrace}");
            writer.WriteLine("-------------------------------------------------------");
            writer.Close();

        }
    }
}
